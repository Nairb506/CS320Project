import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);

        assertTrue(contactService.getContacts().containsKey("1"));
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        contactService.deleteContact("1");

        assertFalse(contactService.getContacts().containsKey("1"));
    }

    @Test
    public void testUpdateContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        contactService.updateContact("1", "Jane", "Smith", null, "456 Side St");

        assertEquals("Jane", contactService.getContacts().get("1").getFirstName());
        assertEquals("Smith", contactService.getContacts().get("1").getLastName());
        assertEquals("1234567890", contactService.getContacts().get("1").getPhone());
        assertEquals("456 Side St", contactService.getContacts().get("1").getAddress());
    }

    // Additional tests as needed
}
