import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;

    // Constructor
    public ContactService() {
        this.contacts = new HashMap<>();
    }

    // Add contact
    public void addContact(Contact contact) {
        contacts.put(contact.getContactId(), contact);
    }

    // Delete contact by ID
    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    // Update contact fields by ID
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contacts.containsKey(contactId)) {
            Contact existingContact = contacts.get(contactId);
            // Update only non-null and non-updatable fields
            if (firstName != null) {
                existingContact = new Contact(contactId, firstName, existingContact.getLastName(),
                        existingContact.getPhone(), existingContact.getAddress());
            }
            if (lastName != null) {
                existingContact = new Contact(contactId, existingContact.getFirstName(), lastName,
                        existingContact.getPhone(), existingContact.getAddress());
            }
            if (phone != null) {
                existingContact = new Contact(contactId, existingContact.getFirstName(), existingContact.getLastName(),
                        phone, existingContact.getAddress());
            }
            if (address != null) {
                existingContact = new Contact(contactId, existingContact.getFirstName(), existingContact.getLastName(),
                        existingContact.getPhone(), address);
            }

            contacts.put(contactId, existingContact);
        }
    }

    // Other methods as needed
}
